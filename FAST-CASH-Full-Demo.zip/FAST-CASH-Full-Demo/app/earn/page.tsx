import {currentTelegramUser} from "@/lib/session";import {adminDb} from "@/lib/supabase-admin";
export const dynamic="force-dynamic";
export default async function Earn(){const tg=await currentTelegramUser();let tasks:any[]=[];
 if(tg){const {data}=await adminDb().from("tasks").select("id,title,description,reward_bdt").eq("active",true);tasks=data||[];}
 return <main className="wrap"><a href="/">← হোম</a><h1>টাস্ক</h1>{!tg?<p>Telegram Mini App থেকে খুলুন।</p>:tasks.map(t=><section className="card" key={t.id}><h2>{t.title}</h2><p>{t.description}</p><p>ডেমো রিওয়ার্ড: ৳{t.reward_bdt}</p><form action="/api/demo/claim" method="post"><input type="hidden" name="taskId" value={t.id}/><p className="small">ডেমো API ব্যবহার করতে পেজের নিচের নির্দেশনা অনুসরণ করুন।</p></form></section>)}<p className="warn">এই ডেমো টাস্কের রিওয়ার্ড বাস্তব অর্থ নয়।</p></main>}
