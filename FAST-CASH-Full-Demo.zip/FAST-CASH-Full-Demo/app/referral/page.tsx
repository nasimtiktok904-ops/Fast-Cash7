import {currentTelegramUser} from "@/lib/session";
export const dynamic="force-dynamic";
export default async function Referral(){const tg=await currentTelegramUser();return <main className="wrap"><a href="/">← হোম</a><h1>রেফার</h1><section className="card"><p>আপনার Telegram ID: {tg?.id||"Telegram থেকে খুলুন"}</p><p>প্রস্তাবিত রেফার বোনাস: ৳৬ (শুধু ডেমো কনফিগারেশন)।</p><p className="small">প্রকৃত রেফার বোনাস চালু করতে নতুন ব্যবহারকারীর Telegram যাচাই, একবারই বোনাস, প্রতারণা প্রতিরোধ এবং সার্ভার-সাইড লেজার যোগ করতে হবে।</p></section></main>}
