import "./style.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title:"FAST CASH", description:"FAST CASH demo app" };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="bn"><body>{children}</body></html>;
}
