import { NextResponse } from "next/server";
import { currentTelegramUser } from "@/lib/session";
import { adminDb } from "@/lib/supabase-admin";
export async function GET(){
 const tg=await currentTelegramUser(); if(!tg)return NextResponse.json({error:"Unauthorized"},{status:401});
 const db=adminDb();
 const {data,error}=await db.from("profiles").upsert({telegram_id:String(tg.id),display_name:tg.first_name||"User"},{onConflict:"telegram_id"}).select("telegram_id,display_name,balance_bdt").single();
 if(error)return NextResponse.json({error:"Database error"},{status:500});
 return NextResponse.json(data);
}