import { NextResponse } from "next/server";
import { currentTelegramUser } from "@/lib/session";
import { adminDb } from "@/lib/supabase-admin";
export async function GET(){
 const tg=await currentTelegramUser();if(!tg)return NextResponse.json({error:"Unauthorized"},{status:401});
 const db=adminDb();const {data,error}=await db.from("tasks").select("id,title,description,reward_bdt").eq("active",true).order("created_at");
 if(error)return NextResponse.json({error:"Database error"},{status:500});
 return NextResponse.json(data);
}