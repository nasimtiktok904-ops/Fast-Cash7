import { NextRequest,NextResponse } from "next/server";
import { currentTelegramUser } from "@/lib/session";
import { adminDb } from "@/lib/supabase-admin";
export async function POST(req:NextRequest){
 if(process.env.DEMO_MODE!=="true")return NextResponse.json({error:"Demo mode only"},{status:403});
 const tg=await currentTelegramUser();if(!tg)return NextResponse.json({error:"Unauthorized"},{status:401});
 const body=await req.json();const amount=Number(body.amount);const method=String(body.method||"");const account=String(body.account||"").trim();
 if(!Number.isFinite(amount)||amount<100||!["bKash","Nagad"].includes(method)||account.length<5)return NextResponse.json({error:"সঠিক তথ্য দিন; সর্বনিম্ন ৳১০০"},{status:400});
 const db=adminDb();const {data:p}=await db.from("profiles").select("balance_bdt").eq("telegram_id",String(tg.id)).single();
 if(!p||Number(p.balance_bdt)<amount)return NextResponse.json({error:"পর্যাপ্ত ডেমো ব্যালেন্স নেই"},{status:400});
 const {error}=await db.from("withdrawal_requests").insert({telegram_id:String(tg.id),amount_bdt:amount,method,account,status:"demo_pending"});
 if(error)return NextResponse.json({error:"Request failed"},{status:500});
 return NextResponse.json({ok:true,message:"ডেমো রিকোয়েস্ট জমা হয়েছে; কোনো টাকা পাঠানো হবে না।"});
}