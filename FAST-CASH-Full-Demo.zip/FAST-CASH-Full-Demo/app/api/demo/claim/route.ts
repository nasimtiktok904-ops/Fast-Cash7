import { NextRequest,NextResponse } from "next/server";
import { currentTelegramUser } from "@/lib/session";
import { adminDb } from "@/lib/supabase-admin";
export async function POST(req:NextRequest){
 if(process.env.DEMO_MODE!=="true")return NextResponse.json({error:"Demo mode disabled"},{status:403});
 const tg=await currentTelegramUser();if(!tg)return NextResponse.json({error:"Unauthorized"},{status:401});
 const {taskId}=await req.json();const db=adminDb();
 const {data:task}=await db.from("tasks").select("id,title,reward_bdt").eq("id",taskId).eq("active",true).maybeSingle();
 if(!task)return NextResponse.json({error:"Task not found"},{status:404});
 const {data:claim}=await db.from("task_claims").insert({telegram_id:String(tg.id),task_id:task.id}).select("id").maybeSingle();
 if(!claim)return NextResponse.json({error:"এই টাস্ক আগে নেওয়া হয়েছে বা ডাটাবেসে সমস্যা হয়েছে"},{status:409});
 const {data:profile}=await db.from("profiles").select("balance_bdt").eq("telegram_id",String(tg.id)).single();
 const newBalance=Number(profile?.balance_bdt||0)+Number(task.reward_bdt);
 const {error}=await db.from("profiles").update({balance_bdt:newBalance}).eq("telegram_id",String(tg.id));
 if(error){await db.from("task_claims").delete().eq("id",claim.id);return NextResponse.json({error:"Balance update failed"},{status:500});}
 await db.from("transactions").insert({telegram_id:String(tg.id),type:"demo_task",amount_bdt:task.reward_bdt,note:task.title});
 return NextResponse.json({ok:true,balance_bdt:newBalance});
}