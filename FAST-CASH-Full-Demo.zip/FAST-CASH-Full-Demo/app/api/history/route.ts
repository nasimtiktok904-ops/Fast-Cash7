import {NextResponse} from "next/server";
import {currentTelegramUser} from "@/lib/session";
import {adminDb} from "@/lib/supabase-admin";
export async function GET(){
 const tg=await currentTelegramUser();if(!tg)return NextResponse.json({error:"Unauthorized"},{status:401});
 const db=adminDb();const [tx,wd]=await Promise.all([
 db.from("transactions").select("id,type,amount_bdt,note,created_at").eq("telegram_id",String(tg.id)).order("created_at",{ascending:false}).limit(50),
 db.from("withdrawal_requests").select("id,amount_bdt,method,status,created_at").eq("telegram_id",String(tg.id)).order("created_at",{ascending:false}).limit(50)]);
 return NextResponse.json({transactions:tx.data||[],withdrawals:wd.data||[]});
}