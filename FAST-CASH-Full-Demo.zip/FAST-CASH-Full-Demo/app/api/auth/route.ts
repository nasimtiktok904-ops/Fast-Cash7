import { NextRequest, NextResponse } from "next/server";
import { verifyTelegramInitData } from "@/lib/telegram";
export async function POST(req:NextRequest){
 const {initData}=await req.json();
 const user=verifyTelegramInitData(String(initData||""));
 if(!user) return NextResponse.json({error:"Telegram verification failed"},{status:401});
 const res=NextResponse.json({ok:true});
 res.cookies.set("tg_init_data",String(initData),{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"strict",path:"/",maxAge:3600});
 return res;
}