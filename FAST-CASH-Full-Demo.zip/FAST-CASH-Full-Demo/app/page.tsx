import Link from "next/link";
import { currentTelegramUser } from "@/lib/session";
import { adminDb } from "@/lib/supabase-admin";
export const dynamic="force-dynamic";
export default async function Home(){
 const tg=await currentTelegramUser();
 let profile:any=null;
 if(tg){const db=adminDb();const {data}=await db.from("profiles").select("balance_bdt,display_name").eq("telegram_id",String(tg.id)).maybeSingle();profile=data;}
 return <main className="wrap">
 <header className="top"><div className="brand">FAST CASH</div><span className="small">DEMO MODE</span></header>
 <h1>স্বাগতম{tg ? `, ${profile?.display_name || tg.first_name || "ব্যবহারকারী"}` : ""}</h1>
 {!tg ? <section className="card"><p>Telegram Mini App থেকে খুলুন। আপনার Telegram পরিচয় যাচাই না হলে ব্যক্তিগত ব্যালেন্স দেখানো হবে না।</p><p className="small">লোকাল ব্রাউজারে পরীক্ষা করতে Telegram WebApp initData প্রয়োজন।</p></section> :
 <section className="card"><div className="muted">আপনার ব্যালেন্স</div><div className="balance">৳{Number(profile?.balance_bdt||0).toFixed(2)}</div><p className="small">আপনার অ্যাকাউন্টের ব্যালেন্স অন্য ব্যবহারকারীর থেকে আলাদা।</p></section>}
 <nav className="nav"><Link className="btn" href="/earn">টাস্ক</Link><Link className="btn btn2" href="/referral">রেফার</Link><Link className="btn btn2" href="/withdraw">উইথড্র</Link><Link className="btn btn2" href="/history">হিস্ট্রি</Link><Link className="btn btn2" href="/admin">অ্যাডমিন</Link></nav>
 <div className="warn">এটি পরীক্ষামূলক ডেমো। এখানে দেখানো ব্যালেন্স বাস্তব টাকা নয় এবং কোনো পেমেন্ট করা হয় না।</div>
 </main>;
}