 "use client";
import {useEffect,useState} from "react";
export default function History(){const [data,setData]=useState<any>(null);useEffect(()=>{fetch("/api/history").then(r=>r.json()).then(setData)},[]);
 return <main className="wrap"><a href="/">← হোম</a><h1>লেনদেনের ইতিহাস</h1>{!data?<p>লোড হচ্ছে...</p>:<><h2>ব্যালেন্স পরিবর্তন</h2>{(data.transactions||[]).map((x:any)=><div className="row" key={x.id}><span>{x.note||x.type}</span><b>৳{x.amount_bdt}</b></div>)}<h2>উইথড্র রিকোয়েস্ট</h2>{(data.withdrawals||[]).map((x:any)=><div className="row" key={x.id}><span>{x.method} · {x.status}</span><b>৳{x.amount_bdt}</b></div>)}</>}</main>}
