create extension if not exists pgcrypto;
create table if not exists public.profiles(
 id uuid primary key default gen_random_uuid(),
 telegram_id text unique not null,
 display_name text not null default 'User',
 balance_bdt numeric(12,2) not null default 0 check(balance_bdt>=0),
 created_at timestamptz not null default now()
);
create table if not exists public.tasks(
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text not null default '',
 reward_bdt numeric(12,2) not null default 0 check(reward_bdt>=0),
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.task_claims(
 id uuid primary key default gen_random_uuid(),
 telegram_id text not null references public.profiles(telegram_id),
 task_id uuid not null references public.tasks(id),
 created_at timestamptz not null default now(),
 unique(telegram_id,task_id)
);
create table if not exists public.transactions(
 id uuid primary key default gen_random_uuid(),
 telegram_id text not null references public.profiles(telegram_id),
 type text not null,
 amount_bdt numeric(12,2) not null,
 note text,
 created_at timestamptz not null default now()
);
create table if not exists public.withdrawal_requests(
 id uuid primary key default gen_random_uuid(),
 telegram_id text not null references public.profiles(telegram_id),
 amount_bdt numeric(12,2) not null check(amount_bdt>=100),
 method text not null check(method in ('bKash','Nagad')),
 account text not null,
 status text not null default 'pending',
 created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.task_claims enable row level security;
alter table public.transactions enable row level security;
alter table public.withdrawal_requests enable row level security;
-- No anon/authenticated policies: browser cannot read or change balances.
-- Server uses service role only after verifying Telegram initData.
insert into public.tasks(title,description,reward_bdt) values
('স্বাগতম টাস্ক','ডেমো সিস্টেম পরীক্ষা করুন',5),
('ড্যাশবোর্ড দেখুন','ড্যাশবোর্ডের তথ্য দেখুন',2),
('হিস্ট্রি দেখুন','লেনদেনের ইতিহাস পেজ খুলুন',1)
on conflict do nothing;
