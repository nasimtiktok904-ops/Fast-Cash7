import { cookies } from "next/headers";
import { verifyTelegramInitData } from "./telegram";
export async function currentTelegramUser() {
  const data = cookies().get("tg_init_data")?.value;
  if (!data) return null;
  return verifyTelegramInitData(data);
}
