# FAST CASH — Full Demo Starter

এটি একটি চালু করার মতো **ডেমো কোডবেস**, বাস্তব অর্থ উপার্জন বা পেমেন্টের প্রোডাকশন সিস্টেম নয়।

## কী আছে
- Next.js App Router
- Supabase-এ প্রত্যেক Telegram ID-এর জন্য আলাদা profile ও balance
- Telegram WebApp initData-এর server-side HMAC যাচাই
- ব্যক্তিগত ব্যালেন্স সার্ভার থেকে পড়া
- ডেমো task claim (একই task একবার)
- demo withdrawal request (৳১০০ minimum, bKash/Nagad selection; কোনো টাকা পাঠায় না)
- ব্যক্তিগত transaction history
- allowlisted Telegram ID-ভিত্তিক read-only admin overview
- RLS enabled; browser-এর anon key দিয়ে balance পড়া/লেখার policy নেই

## 1. Supabase
1. Supabase project খুলে SQL Editor-এ `supabase/migrations/001_schema.sql` চালান।
2. Project Settings → API থেকে Project URL ও publishable/anon key নিন।
3. Service role key গোপন রাখুন; কখনো `NEXT_PUBLIC_` prefix দেবেন না।

## 2. Environment
`.env.example` কপি করে `.env.local` বানান এবং মান বসান:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `TELEGRAM_BOT_TOKEN`
- `ADMIN_TELEGRAM_IDS` (কমা দিয়ে আলাদা করা Telegram numeric ID)
- `DEMO_MODE=true`

কোনো secret GitHub-এ commit করবেন না।

## 3. চালানো
```bash
npm install
npm run dev
```
তারপর `http://localhost:3000`।

## 4. Telegram Mini App
- BotFather-এ Mini App/Web App URL সেট করুন (Vercel deploy URL)।
- Telegram WebApp SDK থেকে `Telegram.WebApp.initData` নিয়ে `/api/auth`-এ POST করুন:
```js
await fetch("/api/auth", {
  method:"POST",
  headers:{"Content-Type":"application/json"},
  body:JSON.stringify({initData: window.Telegram.WebApp.initData})
});
```
- এরপর `/api/me` কল করুন। `/api/auth` ছাড়া ব্যক্তিগত API-গুলো Unauthorized দেবে।
- HTTPS deploy আবশ্যক।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই কোড demo mode-এর জন্য। ডেমো task claim-এ balance update-এর জন্য production-grade atomic SQL function/ledger reconciliation এখনো দরকার।
- referral bonus, verified ad network callbacks, real admin approval, payout integration, rate limiting, fraud controls, audit logs, idempotency, support/dispute workflow নেই।
- withdraw request শুধু `demo_pending` নয়, request জমা করে; কোনো বাস্তব অর্থ পাঠানো হয় না।
- Production-এ যাওয়ার আগে balance পরিবর্তনকে PostgreSQL transaction/RPC-তে স্থানান্তর করুন, unique idempotency key ও immutable ledger ব্যবহার করুন, concurrency/fraud/security test করুন।
- Real-money provider account, terms, legal/compliance এবং adult review প্রয়োজন হতে পারে। অপ্রাপ্তবয়স্ক অবস্থায় payment/provider account নিজে খুলবেন না; অভিভাবকের সহায়তা নিন।
